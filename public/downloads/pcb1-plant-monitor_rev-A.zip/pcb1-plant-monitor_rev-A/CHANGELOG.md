# Changelog — PCB 1, ESP32-S3 Wi-Fi Plant Monitor

## Rev A

- **2026-08-24** — Firmware written against the hardware contract: deep-sleep wake cycle, battery cut-offs, MQTT with Home Assistant discovery.
- **2026-08-21** — Ordered at JLCPCB: 5 boards, fabricated and assembled. The uploaded package is frozen in `03_fabrication/` and `04_assembly/`.
- **2026-08-17** — Final layout audit: 0 DRC errors, 0 unconnected items, 0 schematic-parity differences. Cleared to order.
- **2026-08-16** — DRC / ERC cleanup and finishing review (silkscreen, branding, DNP and BOM exclusions).
- **2026-08-15** — Routing complete; stitching vias added around the RF module.
- **2026-08-10 → 08-12** — Placement review and re-check; outline reduced to 62.5 × 44.5 mm with R4.25 corners.
- **2026-08-02** — USB-C footprint made project-local; shield-leg drill corrected to the connector drawing.
- **2026-07-22** — Second, independent netlist review. No blocking findings; cleared for layout.
- **2026-07-20** — Pre-fabrication design review: three blocking findings (USB-C ground pins, battery-sense chain, stale BOM), all fixed the same day.
- **2026-07-14** — Schematic capture started.
