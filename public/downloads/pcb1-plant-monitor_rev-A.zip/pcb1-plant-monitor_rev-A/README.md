# PCB 1 — ESP32-S3 Wi-Fi Plant Monitor, Rev A

Ray Malik · MuffinByteLabs · muffinbytelabs.com · muffinbytelabs@gmail.com

This is the complete hand-off for one board, organized the way every
project is delivered. Open the folders in order: each one is what the next
person in the chain needs, and nothing else.

| Folder | What is in it | Who uses it |
|---|---|---|
| `01_schematic/` | The full 8-sheet schematic as a PDF | Anyone reviewing the circuit — no design tool needed |
| `02_source/` | The editable design project: schematic, 4-layer board, project-local libraries and 3D models | The next engineer, for any change |
| `03_fabrication/` | The Gerber + drill zip exactly as uploaded, fab layer plots, and the order notes | The PCB fab — zip it and upload |
| `04_assembly/` | BOM with LCSC part numbers, pick-and-place (CPL), and a readable BOM | The assembly house |
| `05_3d/` | Renders of the populated board, and a glTF 3D model | Enclosure and mechanical work |
| `06_docs/` | Design document, the six review records, bring-up guide, pin map, engineering notes, Rev B plan | Bring-up, and the next revision |
| `07_firmware/` | The Arduino sketch for the ESP32-S3 | Bring-up and the demo application |

**Board:** 62.5 × 44.5 mm, 4-layer (signal / GND / GND / signal), 1.6 mm,
lead-free HASL. ESP32-S3-WROOM-1, USB-C with 1-cell LiPo charging,
BME280 + VEML7700 + capacitive soil probe.

**Verification:** final layout audit 2026-08-17 — 0 DRC errors, 0
unconnected items, 0 schematic-parity differences
(`06_docs/reviews/Final_Layout_Review_RevA_2026-08-17.md`).

Links inside the documents point at the original repository layout; the
repository itself is at https://github.com/MuffinByteLabs/esp32s3-plant-monitor.
